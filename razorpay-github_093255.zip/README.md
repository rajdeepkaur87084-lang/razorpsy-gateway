
# Razorpay GitHub Version

1. Upload this folder to GitHub.
2. Add environment variables in deployment platform:
   - RAZORPAY_KEY_ID
   - RAZORPAY_KEY_SECRET

Run locally:
```
npm install
npm start
```
